# Translation Contributor List

## Arabic

- [ZG089](https://github.com/ZG089)
- [Jasem Al-heedry](https://crowdin.com/profile/7asem34)

---

## Azerbaijani

- [mnasibzade](https://github.com/mnasibzade)

---

## Chinese (Simplified)

- [xiaokuqwq](https://github.com/xiaokuqwq)

---

## French

- [anaelle-dev](https://github.com/anaelle-dev)
- [GhostFRR](https://github.com/GhostFRR)
- [Stephane !](https://crowdin.com/profile/pallh)

---

## German

- [xxOrdulu52xx](https://github.com/xxOrdulu52xx)

---

## Greek

- [Goku818](https://github.com/Goku818)

---

## Indonesian

- [chisewaguri](https://github.com/chisewaguri)
- [Rem01Gaming](https://github.com/Rem01Gaming)
- [Mesazane](https://github.com/mesazane)

---

## Italian

- [luigimak](https://github.com/luigimak)
- [GRgabrix](https://github.com/GRgabrix)

---

## Japanese

- [reindex-ot](https://github.com/reindex-ot)

---

## Korean

- [dhlrunner](https://github.com/dhlrunner)

---

## Polish

- [Bladius2024](https://github.com/Bladius2024)

---

## Portuguese (Brazilian)

- [JeanxPereira](https://github.com/JeanxPereira)
- [SecretGogeta](https://github.com/SecretGogeta)
- [@Gabriel Santos](https://crowdin.com/profile/gabriellsantosu)

---

## Russian

- [Andfi](https://crowdin.com/profile/andfi)

---

## Spanish

- [Keinta15](https://github.com/Keinta15)
- [Marc Reventós Papo](https://github.com/mpapus)
- [Juan Martín Zavalla](https://crowdin.com/profile/juanma11)

---

## Turkish

- [berkmirsatk](https://github.com/berkmirsatk)
- [cvnertnc](https://github.com/cvnertnc)

---

## Ukrainian

- [StepanSad](https://github.com/StepanSad)
- [IlliaS](https://github.com/IlliaS)
- [Валентин Паник](https://crowdin.com/profile/panikvalentin)

---

## Vietnamese

- [doanvtamhuynh](https://github.com/doanvtamhuynh)
- [SaleOff](https://github.com/SaleOff)
- [Vietnamese's](https://crowdin.com/profile/vietnamesetranslations)
