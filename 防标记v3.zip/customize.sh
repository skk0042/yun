#!/system/bin/sh
SKIPUNZIP=1
MODPATH=$MODPATH

PERSIST_DIR="/mnt/vendor/persist/data"
ui_print " "
ui_print " "
ui_print " 作者: 486"
ui_print " QQ群：288482918"
ui_print " TG: https://t.me/SKK0042NB"
ui_print " "
ui_print " "
ui_print "- 检查目录存在性 $PERSIST_DIR"
if [ ! -d "$PERSIST_DIR" ]; then
    ui_print "× 错误: $PERSIST_DIR 目录不存在"
    abort "安装中止：目录不存在 你的设备用不到此逻辑"
fi

#清理旧配置文件
rm -rf "/data/adb/486"

unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
unzip -o "$ZIPFILE" '486' -d $MODPATH >&2

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/486 0 0 0755


ui_print " "
ui_print "✓ 安装模块完成！"
ui_print " "
