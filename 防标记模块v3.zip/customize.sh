#!/system/bin/sh
SKIPUNZIP=1
MODPATH=$MODPATH

PERSIST_DIR="/mnt/vendor/persist/data"
ui_print " "
ui_print " "
ui_print " 作者: 486"
ui_print " QQ群：288482918"
ui_print " TG: https://t.me/SKK0042NB"
ui_print " "
ui_print " "
ui_print "- 检查目录存在性 $PERSIST_DIR"
if [ ! -d "$PERSIST_DIR" ]; then
    ui_print "× 错误: $PERSIST_DIR 目录不存在"
    abort "安装中止：目录不存在 你的设备用不到此逻辑"
fi

#清理旧配置文件
rm -rf "/data/adb/486"

unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2
unzip -o "$ZIPFILE" '486' -d $MODPATH >&2

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/486 0 0 0755


ui_print " "
ui_print "✓ 安装模块完成！"
ui_print " "
ui_print "✓ 已跳转QQ群，进入组织或者频道获取最新资源或消息"
am start -a android.intent.action.VIEW -d "https://qun.qq.com/universal-share/share?ac=1&authKey=09GHYeotBX4cNL1o8w%2FF8j%2Bfx%2FcPIU0H5tMp5lO8ZXciwUxETL%2BEwe8gPbaldshS&busi_data=eyJncm91cENvZGUiOiIyODg0ODI5MTgiLCJ0b2tlbiI6InZSOUNTWWx1WVNJNWYrNlpUYWZEQkF4dmpQWVVwZFc1N1REVFFjYmpTR25MYldzTWxnK2NZRXhiVEZkbUtIUE8iLCJ1aW4iOiI0Mjg1NzkifQ%3D%3D&data=WwMC8aE8oVTgoGkPUiXAIs8nMVJZU4UkiWcX8qYMoFoNnTpIwVY7GCCZRX_1UO_Yi8udPzZuE_jESwmq4ABrwQ&svctype=4&tempid=h5_group_info"  >/dev/null 2>&1
