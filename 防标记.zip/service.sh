#!/system/bin/sh
MODDIR=$(dirname "$(realpath "$0" 2>/dev/null || readlink -f "$0")")

ORIGINAL_ELF="$MODDIR/486"
TARGET_DIR="/data/adb"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

props=(
    "ro.boot.verifiedbootstate=green"
    "ro.boot.verifiedbootstate_lock=green"
    "ro.boot.vbmeta.device_state=locked"
    "ro.boot.flash.locked=1"
    "ro.boot.veritymode=enforcing"
    "ro.boot.enable_dm_verity=1"
    "ro.boot.secureboot=1"
    "ro.boot.bootlock=locked"
    "ro.oem_unlock_supported=0"
    "sys.oem_unlock_allowed=0"
    "ro.boot.warranty_bit=0"
    "ro.fmp_config=1"
    "ro.boot.realme_lockstate=locked"
    "ro.boot.hwc=CN"
    "ro.boot.hwcountry=CN"
)

for prop in "${props[@]}"; do
    prop_name=${prop%=*}
    prop_value=${prop#*=}
    resetprop -n "$prop_name" "$prop_value" 2>/dev/null
    setprop "$prop_name" "$prop_value" 2>/dev/null
done

resetprop --file /system/build.prop 2>/dev/null

if [ ! -f "$ORIGINAL_ELF" ]; then
    exit 1
fi

if [ ! -w "$TARGET_DIR" ]; then
    exit 1
fi

generate_random_name() {
    cat /dev/urandom 2>/dev/null | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1
}

RANDOM_NAME=$(generate_random_name)
TARGET_ELF="$TARGET_DIR/$RANDOM_NAME"

while [ -e "$TARGET_ELF" ]; do
    RANDOM_NAME=$(generate_random_name)
    TARGET_ELF="$TARGET_DIR/$RANDOM_NAME"
done

if ! cp "$ORIGINAL_ELF" "$TARGET_ELF"; then
    exit 1
fi
chmod 0755 "$TARGET_ELF"

export USER=root
export HOME=/data/local/tmp
export TMPDIR=/data/local/tmp
export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin
export LD_LIBRARY_PATH=/system/lib64:/vendor/lib64:/system/lib:/vendor/lib

cd /data/local/tmp || exit 1

"$TARGET_ELF" &
PID=$!

rm -f "$TARGET_ELF"

exit 0